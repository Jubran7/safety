import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:toast/toast.dart';

import '../PageMain/PageMain.dart';
import '../doctor/doctorLogin.dart';
import '../gloals.dart';
import '../patient/products_page.dart';
import 'ProdactDetails.dart';
import 'medDetails.dart';

class CustomTileProdact extends StatefulWidget {
  final bool delBtn;
  late final DocumentSnapshot snapshot;
  final BuildContext  context2;

  CustomTileProdact({required this.delBtn, required this.snapshot, required this.context2,});

  @override
  _CustomTileState createState() => _CustomTileState();
}

class _CustomTileState extends State<CustomTileProdact> {
  late String currentUser;
  QuerySnapshot? qn ;
  late Map<String, dynamic> data;
  Future getDiseaseInfo() async {
    var firestore = FirebaseFirestore.instance.collection('medi');
    qn = await firestore.get();
    var mmm=qn?.docs;
    for (var queryDocumentSnapshot in mmm!) {
      Object? data = queryDocumentSnapshot.data();

    }


    return qn?.docs;
  }


  profileUpdate(String id ,bool state) {

    FirebaseFirestore.instance
        .collection('medi')
        .doc(id)
        .set(
        {'Name':data['Name'],
          'Descrbtion':data['Descrbtion'],
          'Dose':data['Dose'],
          'tybe':data['tybe'],
          'url':data['url'],
          'favorite':state
        });
  //  Toast.show('$state', backgroundColor: Colors.blue, backgroundRadius: 5,duration: 2);
    getDiseaseInfo();
    setState(() {
//      super.build(widget.context2);
      initState();
    });

  }
void initState(){


  getDisease();
}
  getDisease(){
 data=this.widget.snapshot.data()as Map<String, dynamic>;
 }
// -------------- create this method to get the current user
//   Future<Null> _getCurrentUser() async {
//     var result = await firebaseHelper().getCurrentUser();
//
// //we notified that there was a change and that the UI should be rendered
//     setState(() {
//       currentUser = result;
//     });
//   }
  _deleteDisease(BuildContext context) {
    FirebaseFirestore.instance
        .collection('medi')
    //.doc('disName')
     .doc(data['Name'])
        .delete().then((value)
    {

    });
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => DeletingWait()));
    setState(() {

    });
  }
  ProductsPage xx=ProductsPage(detailsUser: details);

 late bool vi;
  var ic=Icons.star_border;
  var col=Colors.brown;
  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
       vi=data['favorite'];
    double height = MediaQuery.of(context).size.height;

    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    ProdactDetails2(
                      snapshot: widget.snapshot, doctorName: 'Ahmed',
                    )
            )
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
        height: height * 0.1,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(8)),
          gradient: new LinearGradient(colors: [
            Colors.blueAccent.withOpacity(0.1),
            !widget.delBtn
                ? Colors.blueGrey.withOpacity(0.2)
                : Colors.redAccent.withOpacity(0.2),
          ]),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Image(image: NetworkImage(data['url'])),

            Text(
              data['Name'],
              style: GoogleFonts.lato(fontSize: height * 0.03, letterSpacing: 2),
            ),

            Row(
              children: [
                Positioned(
                  child:IconButton(
                   icon:Icon( vi?Icons.star:Icons.star_border,
                    color:vi?Colors.amber: Colors.brown,
                    size: height * 0.032),
                    onPressed: () {
                    setState(() {
                      vi=!vi;
                      profileUpdate(data['Name'],vi);
                      ProductsPage( detailsUser: details);
                    });
                    },)
                  // IconButton(
                  //   icon:Icon(
                  //   Icons.star_border,
                  //   color: Colors.brown,
                  //   size: height * 0.032),
                  //   onPressed: () {
                  //     setState(() {
                  //
                  //       profileUpdate(data['Name'],true);
                  //       this.widget.snapshot=qn?.docs as  DocumentSnapshot;
                  //
                  //     });
                  //   },)
                ),
                ElevatedButton(
                  onPressed: () {
                    widget.delBtn
                        ? _deleteDisease(context)
                        :setState(() {
                      xx.createState();

                    });

                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //         builder: (context) =>
                    //             MainPage(title: 'ali', detailsUser2: details,
                    //             )
                    //     )
                    // );
                  },
                  style: ElevatedButton.styleFrom(
                    shape: CircleBorder(),
                  ),
                  child: Icon(
                    Icons.arrow_forward_ios,
                    color: Colors.black,
                    size: height * 0.032,

                )
                ),
              ],
            ),




          ],
        ),
      ),
    );
  }

}

class DeletingWait extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);

    Future.delayed(Duration(seconds: 2), () {
      Navigator.pop(context);
      Toast.show("Deleted Successfully!", backgroundRadius: 5, backgroundColor: Colors.red, duration: 3);
    });
    return Scaffold(
      body: SafeArea(
        child: Container(
          height: MediaQuery
              .of(context)
              .size
              .height,
          width: MediaQuery
              .of(context)
              .size
              .width,
          color: Colors.white,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
                ),
                SizedBox(
                  height: MediaQuery
                      .of(context)
                      .size
                      .height * 0.1,
                ),
                Text(
                  'Deleting Please Wait...',
                  style: TextStyle(color: Colors.red, fontSize: 17),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class CustomTileFavorits extends StatefulWidget {

  final bool delBtn;
  final DocumentSnapshot snapshot;

  CustomTileFavorits({required this.delBtn, required this.snapshot});

  @override
  _CustomTileFavoritsState createState() => _CustomTileFavoritsState();
}

class _CustomTileFavoritsState extends State<CustomTileFavorits> {
  late String currentUser;
  late Map<String, dynamic> data;
  getDisease(){
    data=this.widget.snapshot.data()as Map<String, dynamic>;
  }

  _deleteDisease(BuildContext context) {
    FirebaseFirestore.instance
        .collection('medi')
    //.doc('disName')
        .doc(data['Name'])
        .delete().then((value)
    {

    });
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => DeletingWait()));
    setState(() {

    });
  }


  @override
  Widget build(BuildContext context) {
    getDisease();
    ToastContext().init(context);

    double height = MediaQuery.of(context).size.height;

    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    ProdactDetails2(
                      snapshot: widget.snapshot, doctorName: 'Ahmed',
                    )
            )
        );
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
        height: height * 0.1,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(8)),
          gradient: new LinearGradient(colors: [
            Colors.blueAccent.withOpacity(0.1),
            !widget.delBtn
                ? Colors.blueGrey.withOpacity(0.2)
                : Colors.redAccent.withOpacity(0.2),
          ]),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Image(image: NetworkImage(data['url'])),

            Text(
              data['Name'],
              style: GoogleFonts.lato(fontSize: height * 0.03, letterSpacing: 2),
            ),

            ElevatedButton(
              onPressed: () {
                widget.delBtn
                    ? _deleteDisease(context)
                    : Toast.show('Added Favorit Successfully!',
                    backgroundRadius: 5,
                    backgroundColor: Colors.amber,
                    duration: 3);


              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white70,
                shape: CircleBorder(),
              ),
              child: widget.delBtn
                  ?Icon(
                Icons.star_border,
                color: Colors.brown,
                size: height * 0.032,
              ):Icon(
              Icons.star,
              color: Colors.amber,

              size: height * 0.032,
            )
                    ,
            )
          ],
        ),
      ),
    );
  }

}
