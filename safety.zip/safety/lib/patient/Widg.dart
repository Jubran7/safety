import 'package:flutter/cupertino.dart';

class WidgetA extends StatefulWidget {
  const WidgetA({Key? key}) : super(key: key);

  @override
  State<WidgetA> createState() => _WidgetAState();
  static GlobalKey<_WidgetAState> creatkey()=>GlobalKey<_WidgetAState>();
}

class _WidgetAState extends State<WidgetA> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
extension  on GlobalKey<_WidgetAState>{


  void mm(){
    print('m');
}
}

