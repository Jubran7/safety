import 'transaction.dart';
class TransactionBundle{
  String date;
 late List<Transaction> transactionList;

  late int _totalIncome;

   TransactionBundle(this.date, this.transactionList);

  int get totalIncomePerDay {
    _totalIncome = 0;
    transactionList.forEach((v) {
      _totalIncome += v.totalPrice;
    });
    return _totalIncome;
  }
}